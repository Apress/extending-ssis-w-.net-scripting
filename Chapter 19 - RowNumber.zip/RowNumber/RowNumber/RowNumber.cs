﻿using System;
using Microsoft.SqlServer.Dts.Pipeline;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;

namespace ScriptingBook.RowNumber
{
    [DtsPipelineComponent(
    DisplayName = "Row Number",
    ComponentType = ComponentType.Transform,
    Description = "Adds a rownumber to the output, based on the seed and increment values.",
    IconResource = "ScriptingBook.RowNumber.RowNumber.ico",
    UITypeName = "ScriptingBook.RowNumber.RowNumberInterface, ScriptingBook.RowNumber.RowNumberUI, Version=1.0.0.0, Culture=Neutral, PublicKeyToken=80664248b6de6485",
    CurrentVersion = 1
)]
    public class RowNumber : PipelineComponent
    {
        // Default values of the properties
        private Int64 _seed = 1;
        private int _increment = 1;
        private string _newColumnName = "RowNumber";

        // Various class variables
        private bool areInputColumnsValid = true;
        private Int64 _currentRowNumber;    // Keep track of the rownumber
    
        #region DesignTime
        /// <summary>
        /// Called when the component is initially added
        /// to the data flow task. Add the input, output,
        /// and we add default a New Column to store the
        /// Rownumber in.
        /// </summary>
        public override void ProvideComponentProperties()
        {
            // Add the input
            IDTSInput100 input = ComponentMetaData.InputCollection.New();
            input.Name = "RowNumberInput";
            // We don't use the ErrorRowDisposition.
            // If we fail somewhere in the rows, we
            // don't wan't it to go to an alternative output buffer.
            input.ErrorRowDisposition = DTSRowDisposition.RD_NotUsed;

            // Add the output (Synchronous)
            // Async creates new buffers
            // Sync adds columns to existing buffers
            // SynchronousInputID connects the input
            // and output for sync components
            IDTSOutput100 output = ComponentMetaData.OutputCollection.New();
            output.Name = "RowNumberOutput";
            output.SynchronousInputID = input.ID;
            output.ExclusionGroup = 1;

            // Initially we start with a new output column
            // with a default name. In the UI you can change
            // this name. The Default datatype is DT_I8. You
            // could add a combobox with datatypes to let the
            // user choose which datatype to use.
            IDTSOutputColumn100 outputColumn = output.OutputColumnCollection.New();
            outputColumn.Name = _newColumnName;
            outputColumn.Description = "Generated Rownumber";
            outputColumn.SetDataTypeProperties(DataType.DT_I8, 0, 0, 0, 0);
  
            // Define the CustomProperties of the this component
            AddProperty("Seed", "Starting number.", _seed, false);
            AddProperty("Increment", "Increment size.", _increment, false);

            // Workaround for versioning bug by Todd McDermid
            // http://toddmcdermid.blogspot.com/2010/09/set-componentmetadataversion-in.html
            // When adding the component to the data flow the
            // version number is saved in the package. When
            // a new component version is installed then the
            // PerformUpgrade method can handle the changes.
            DtsPipelineComponentAttribute componentAttribute = (DtsPipelineComponentAttribute)
                                            Attribute.GetCustomAttribute(this.GetType(), 
                                            typeof(DtsPipelineComponentAttribute), false);
            ComponentMetaData.Version = componentAttribute.CurrentVersion;
        }

        /// <summary>
        /// The ReinitializeMetaData method is where all the building work for your component is done. You
        /// add new columns, remove invalid columns, and generally build up the columns. It is called when the
        /// Validate method returns VS_NEEDSNEWMETADATA. It is also your opportunity in the component to do
        /// any repairs that need to be done, particularly around invalid columns as mentioned previously.
        /// </summary>
        public override void ReinitializeMetaData()
        {
            if (!ComponentMetaData.AreInputColumnsValid)
            {
                ComponentMetaData.RemoveInvalidInputColumns();
            }
            base.ReinitializeMetaData();
        }
        #endregion

        public override DTSValidationStatus Validate()
        {
            // boolean used for FireError to specify whether execution is cancelled
            bool pbCancel = false;

            // If you are using an input column and input flow
            // is removed or changed then that could hurt our
            // code. Therefore check if the input columns are
            // still valid
            if (!ComponentMetaData.AreInputColumnsValid)
            {
                return DTSValidationStatus.VS_NEEDSNEWMETADATA;
            }

            // Validate that there is only 1 input
            if (ComponentMetaData.InputCollection.Count != 1)
            {
                ComponentMetaData.FireError(0, ComponentMetaData.Name, "Incorrect number of inputs.", "", 0, out pbCancel);
                return DTSValidationStatus.VS_ISCORRUPT;
            }

            // Validate that there are no input columns
            if (ComponentMetaData.InputCollection[0].InputColumnCollection.Count != 0)
            {
                ComponentMetaData.FireError(0, ComponentMetaData.Name, "Incorrect number of inputs columns.", "", 0, out pbCancel);
                return DTSValidationStatus.VS_ISCORRUPT;
            }

            // Validate that there is only 1 output
            if (ComponentMetaData.OutputCollection.Count != 1)
            {
                ComponentMetaData.FireError(0, ComponentMetaData.Name, "Incorrect number of outputs.", "", 0, out pbCancel);
                return DTSValidationStatus.VS_ISCORRUPT;
            }

            // Validate that there is 1 output column
            if (ComponentMetaData.OutputCollection[0].OutputColumnCollection.Count != 1)
            {
                ComponentMetaData.FireError(0, ComponentMetaData.Name, "Incorrect number of outputs columns", "", 0, out pbCancel);
                return DTSValidationStatus.VS_ISCORRUPT;
            }

            // Validate that the increment isn't zero
            if (_increment == 0)
            {
                ComponentMetaData.FireError(0, ComponentMetaData.Name, "Increment can't be zero", "", 0, out pbCancel);
                return DTSValidationStatus.VS_ISBROKEN;
            }
            return base.Validate();
        }
        
        #region ProcessInput
        public override void PreExecute()
        {
            // Get values from the properties for use in the ProcessInput
            _currentRowNumber = Int64.Parse(this.ComponentMetaData.CustomPropertyCollection["Seed"].Value.ToString());
            _increment = (int)this.ComponentMetaData.CustomPropertyCollection["Increment"].Value;
        }

        /// <summary>
        /// Called when a PipelineBuffer is passed to the component.
        /// </summary>
        /// <param name="inputID">The ID of the Input that the buffer contains rows for.</param>
        /// <param name="buffer">The PipelineBuffer containing the columns defined in the IDTSInput100.</param>
        public override void ProcessInput(int inputID, PipelineBuffer buffer)
        {
            // Loop through the rows in the buffer
            while (buffer.NextRow())
            {
                // Check if the new number isn't out of range.
                // Perhaps less usefull for a bigint with a
                // max size of 9,223,372,036,854,775,807
                if (_currentRowNumber < Int64.MinValue || _currentRowNumber > Int64.MaxValue)
                {
                    // Throw an error, the value can't be contained in the variable type chosen !
                    bool pbCancel = true;
                    ComponentMetaData.FireError(0, this.ComponentMetaData.Name, "Rownumber is not in range of the chosen variables type 'DT_I8 (Int64)'.", "", 0, out pbCancel);
                    throw new ApplicationException("Rownumber is not in range of the chosen variables type 'DT_I8 (Int64)'.");
                }
                // Fill first (0) output column with the rownumber
                buffer.SetInt64(0, _currentRowNumber);
                
                // Increment when ready
                _currentRowNumber = _currentRowNumber + _increment;

                // Direct the row to the defaultOutput
                // (In this case also the only output).
                buffer.DirectRow(ComponentMetaData.OutputCollection[0].ID);
            }

            // If we need to something after all rows
            // have been processed, here is the place
            // to do it.
            //if (buffer.EndOfRowset)
            //{

            //}
        }
        #endregion

        /// <summary>
        /// Helper function for adding custom properties to the ComponentMetaData.CustomPropertyCollection.
        /// </summary>
        /// <param name="name">Name of the custom property.</param>
        /// <param name="description">Description of the custom property.</param>
        /// <param name="value">Value of the custom property.</param>
        /// <param name="supportsExpression">Does the custom property support expressions.</param>
        private void AddProperty(string name, string description, object value, bool supportsExpression)
        {
            // Add a custom property to the component
            IDTSCustomProperty100 commandProp = this.ComponentMetaData.CustomPropertyCollection.New();
            commandProp.Name = name;
            commandProp.Description = description;
            if (supportsExpression)
            {
                // Let SSIS know that we allow expressions on our property
                commandProp.ExpressionType = DTSCustomPropertyExpressionType.CPET_NOTIFY;
            }
            commandProp.Value = value;

            return;
        }


        #region Advanced Editor Overrides (No inserting \ deleting of input(columns) and output(columns)
        // OUTPUT RELATED
        public override IDTSOutput100 InsertOutput(DTSInsertPlacement insertPlacement, int outputID)
        {
            throw new Exception(string.Format("Inserting output to '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        public override void DeleteOutput(int outputID)
        {
            throw new Exception(string.Format("Deleting output from '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        public override IDTSOutputColumn100 InsertOutputColumnAt(int outputID, int outputColumnIndex, string name, string description)
        {
            throw new Exception(string.Format("Adding output column to '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        public override void DeleteOutputColumn(int outputID, int outputColumnID)
        {
            throw new Exception(string.Format("Deleting output column from '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        // INPUT RELATED
        public override IDTSInput100 InsertInput(DTSInsertPlacement insertPlacement, int inputID)
        {
            throw new Exception(string.Format("Inserting input from '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        public override void DeleteInput(int inputID)
        {
            throw new Exception(string.Format("Deleting input from '{0}' isn't allowed.", ComponentMetaData.Name), null);
        }

        public override IDTSInputColumn100 SetUsageType(int inputID, IDTSVirtualInput100 virtualInput, int lineageID, DTSUsageType usageType)
        {
            throw new Exception(string.Format("Changing UsageType isn't allowed.", ComponentMetaData.Name), null);
        }
        #endregion

        public override void PerformUpgrade(int pipelineVersion)
        {
            // Obtain the current component version from the attribute.
            DtsPipelineComponentAttribute componentAttribute = (DtsPipelineComponentAttribute)Attribute.GetCustomAttribute(this.GetType(), typeof(DtsPipelineComponentAttribute), false);
            int binaryVersion = componentAttribute.CurrentVersion;
            int metaDataVersion = ComponentMetaData.Version;

            // If the component version saved in the package is less than
            // the current version, Version 2, perform the upgrade.
            if (metaDataVersion < binaryVersion)
            {
                // Upgrade from version 0 to 1
                if (metaDataVersion == 0)
                {
                    if (ComponentMetaData.CustomPropertyCollection["Increment"] == null)
                    {
                        // Add the new property with a default value
                        AddProperty("Increment", "Increment size.", 1, false);
                    }
                }
                // Update the metadata version otherwise the versions are still different
                // and then next time you open the package it will perform the upgrade
                // again causing errors.
                ComponentMetaData.Version = binaryVersion;
            }

            // Forgot to upgrade the transformation on a server?
            if (metaDataVersion > binaryVersion)
            {
                throw new Exception("Runtime version of the component is out of date. Upgrading the installation can possibly solve this issue");
            }
        }
    }
}
