﻿using System;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Pipeline.Design;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;

// Class, Interfacing for transformation editor
namespace ScriptingBook.RowNumber
{
    public class RowNumberInterface : IDtsComponentUI
    {
        IDTSComponentMetaData100 _cmd;
        IServiceProvider _sp;

        public void Help(System.Windows.Forms.IWin32Window parentWindow)
        {
        }
        public void New(System.Windows.Forms.IWin32Window parentWindow)
        {
        }
        public void Delete(System.Windows.Forms.IWin32Window parentWindow)
        {
        }
        public bool Edit(System.Windows.Forms.IWin32Window parentWindow, Variables variables, Connections connections)
        {
            // Create and display the form for the user interface.

            RowNumberEditor componentEditor = new RowNumberEditor();

            componentEditor.Connections = connections;
            componentEditor.Variables = variables;
            componentEditor.ComponentMetadata = _cmd;
            componentEditor.ServiceProvider = _sp;

            return componentEditor.ShowDialog(parentWindow) == DialogResult.OK;
        }
        public void Initialize(IDTSComponentMetaData100 dtsComponentMetadata, IServiceProvider serviceProvider)
        {
            // Store the component metadata.
            _cmd = dtsComponentMetadata;
            _sp = serviceProvider;
        }
    }
}
