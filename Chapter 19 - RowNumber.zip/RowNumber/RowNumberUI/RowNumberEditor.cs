﻿using System;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;


namespace ScriptingBook.RowNumber
{
    public partial class RowNumberEditor : Form
    {
        // IMPORTANT REMARK !!!
        // Although you can modify the component directly through the IDTSComponentMetaData100 interface, it is better to create an instance of 
        // the CManagedComponentWrapper by using the Instantiate method. When you edit the component directly by using the interface, you bypass 
        // the component's validation safeguards. The advantage of using the design-time instance of the component through 
        // the CManagedComponentWrapper is that you ensure that the component has control over the changes made to it.

        // Wrapper around the DTSComponent.
        private CManagedComponentWrapper _designTimeInstance;

        // Variables and properties for storing objects given to us by the component
        #region Properties
        private Variables _vars = null;
        public Variables Variables
        {
            get { return _vars; }
            set { _vars = value; }
        }

        private Connections _conns = null;
        public Connections Connections
        {
            get { return _conns; }
            set { _conns = value; }
        }

        private IServiceProvider _sp = null;
        public IServiceProvider ServiceProvider
        {
            get { return _sp; }
            set { _sp = value; }
        }

        private IDTSComponentMetaData100 _cmd = null;
        public IDTSComponentMetaData100 ComponentMetadata
        {
            get { return _cmd; }
            set { _cmd = value; }
        }
        #endregion

        // Constructor
        public RowNumberEditor()
        {
            InitializeComponent();
        }

        private void RowNumberEditor_Load(object sender, EventArgs e)
        {
            // Get the name of the new column and fill the textbox
            txtColumnName.Text = _cmd.OutputCollection[0].OutputColumnCollection[0].Name;
            // Cast seed from custom property to bigint
            // and fill the spincontrol
            numSeed.Value = Int64.Parse(_cmd.CustomPropertyCollection["Seed"].Value.ToString());
            // Cast increment from custom property to int
            // and fill the spincontrol
            numIncrement.Value = (int)_cmd.CustomPropertyCollection["Increment"].Value;
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            // Show a help text
            MessageBox.Show("Enter the name of the new column that contains the rownumber.");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            // Only instantiate once. We don't want to add outputs
            // and columns each time we close the editor
            if (_designTimeInstance == null)
            {
                _designTimeInstance = _cmd.Instantiate();
            }

            // Check if the columnname already exists
            // If not change the name of the output column
            IDTSOutputColumn100 outputColumn = _cmd.OutputCollection[0].OutputColumnCollection[0];
            if (outputColumn.Name != txtColumnName.Text)
            {
                outputColumn.Name = txtColumnName.Text;
            }

            // Pass the Seed to the componentProperty
            _designTimeInstance.SetComponentProperty("Seed", (Int64)numSeed.Value);

            // Pass the Incremenent to the componentProperty
            _designTimeInstance.SetComponentProperty("Increment", (int)numIncrement.Value);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Close the window and undo changes
            this.Close();
        }
    }
}
