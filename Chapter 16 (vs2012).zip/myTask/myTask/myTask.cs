﻿using System;
using System.ComponentModel;
using System.IO;
using System.Xml;
using Microsoft.SqlServer.Dts.Runtime;

namespace ScriptingBook.myTask
{
    // Connection to the editor assembly. Copy the PublicKeyToken from the previous step.
    [DtsTask(
    DisplayName = "My Task",
    TaskType = "myTask",
    TaskContact = "ScriptingBook Example",
    IconResource = "ScriptingBook.myTask.myTask.ico",
    UITypeName = "ScriptingBook.myTask.myTaskInterface, ScriptingBook.myTask.myTaskUI, Version=1.0.0.0, Culture=Neutral,PublicKeyToken=80664248b6de6485",
    RequiredProductLevel = DTSProductLevel.None)]
    public class myTask : Task, IDTSComponentPersist
    {

        #region Get Set Properties
        /*
         * The properties of my task that will be
         * saved in the XML of the SSIS package.
         * You can add a Category and Description
         * for each property making it clearer.
         */
        private bool _hasConnectionmanagerSource = true;
        [CategoryAttribute("my Task Source")]
        [Description("True if a connectionmanager is used for the task as source. False if a variable is used.")]
        public bool HasConnectionmanagerSource
        {
            get { return this._hasConnectionmanagerSource; }
            set
            {
                this._hasConnectionmanagerSource = value;
            }
        }

        private string _selectedConnectionManagerIDSource = "";
        [CategoryAttribute("my Task Source")]
        [Description("GUID of the selected source connectionmanager. If a variable is used, then 'SelectedVariableIDSource' is <null>")]
        public string SelectedConnectionManagerIDSource
        {
            get { return this._selectedConnectionManagerIDSource; }
            set { this._selectedConnectionManagerIDSource = value; }
        }

        private string _selectedVariableIDSource = "";
        [CategoryAttribute("my Task Source")]
        [Description("GUID of the selected source variable. If a variable is used, then 'SelectedConnectionManagerIDSource' is <null>")]
        public string SelectedVariableIDSource
        {
            get { return this._selectedVariableIDSource; }
            set { this._selectedVariableIDSource = value; }
        }
        #endregion

        #region Version
        public string Version
        {
            get
            {
                return System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location).ToString();
            }
        }
        #endregion

        #region Variables for internal use
        private ConnectionManager _selectedConnectionManagerSource = null;
        private Variable _selectedVariableSource = null;
        private string _filePathSource = "";
        #endregion

        #region Constructor
        public myTask()
        {

        }
        #endregion

        #region Overrides for Task
        public override void InitializeTask(Connections connections, VariableDispenser variableDispenser, IDTSInfoEvents events, IDTSLogging log, EventInfos eventInfos, LogEntryInfos logEntryInfos, ObjectReferenceTracker refTracker)
        {
            base.InitializeTask(connections, variableDispenser, events, log, eventInfos, logEntryInfos, refTracker);
        }

        public override DTSExecResult Validate(Connections connections, VariableDispenser variableDispenser, IDTSComponentEvents componentEvents, IDTSLogging log)
        {

            // If we have used a ConnectionManager then we check if we have a valid one !
            if (HasConnectionmanagerSource)
            {
                // Check if a connection manager is selected in the combobox
                if (String.IsNullOrEmpty(_selectedConnectionManagerIDSource))
                {
                    componentEvents.FireError(0, "MyTask", "Connectionmanager is mandatory."
                                                , "", 0);
                    return DTSExecResult.Failure;
                }
                // Check if the selected connection manager still exists
                if (FindConnectionManager(connections,
                                            _selectedConnectionManagerIDSource) == null)
                {
                    componentEvents.FireError(0, "MyTask", "Connectionmanager doesn't exist."
                                                , "", 0);
                    return DTSExecResult.Failure;
                }
            }
            else
            // If we decided to use a Variable we at least must have chosen one !
            {
                if (String.IsNullOrEmpty(_selectedVariableIDSource))
                {
                    componentEvents.FireError(0, "My Task", "Selected Source Variable is mandatory", "", 0);
                    return DTSExecResult.Failure;
                }
                if (FindVariable(variableDispenser, _selectedVariableIDSource) == null)
                {
                    componentEvents.FireError(0, "MyTask", "Variable doesn't exist."
                                                , "", 0);
                    return DTSExecResult.Failure;
                }
            }


            /*
                * If you want to do some checks with the value from the connection manager or variable then
                * you have to get that value. You can copy the code from the execute and then use that to
                * validate the filepath from the connection manager or variable.
                */

            return DTSExecResult.Success;
        }

        public override DTSExecResult Execute(Connections connections, VariableDispenser variableDispenser, IDTSComponentEvents componentEvents, IDTSLogging log, object transaction)
        {
            // Get the value from the connection manager or variable
            if (HasConnectionmanagerSource)
            {
                _selectedConnectionManagerSource = FindConnectionManager(connections, _selectedConnectionManagerIDSource);
                _filePathSource = GetFilePathSource(_selectedConnectionManagerSource);
            }
            else
            {
                _selectedVariableSource = FindVariable(variableDispenser, _selectedVariableIDSource);
                _filePathSource = GetFilePathSource(_selectedVariableSource);
            }

            if (!File.Exists(_filePathSource))
            {
                componentEvents.FireError(0, "My Task", "File " + _filePathSource + " doesn't exist", "", 0);
                return DTSExecResult.Failure;
            }
            else
            {
                return DTSExecResult.Success;
            }
        }
        #endregion

        #region Methods for IDTSComponentPersist
        void IDTSComponentPersist.LoadFromXML(System.Xml.XmlElement node, IDTSInfoEvents infoEvents)
        {
            //	This might occur if the task's XML has been modified outside of the Business Intelligence
            //	Or SQL Server Workbenches.
            if (node.Name != "myTask")
            {
                throw new Exception(string.Format("Unexpected task element when loading task - {0}.", "myTask"));
            }
            else
            {
                // populate the private property variables with values from the DTS node.
                this._hasConnectionmanagerSource = Convert.ToBoolean(node.Attributes.GetNamedItem("HasConnectionmanagerSource").Value);
                this._selectedConnectionManagerIDSource = node.Attributes.GetNamedItem("SelectedConnectionManagerIDSource").Value;
                this._selectedVariableIDSource = node.Attributes.GetNamedItem("SelectedVariableIDSource").Value;
            }
        }

        void IDTSComponentPersist.SaveToXML(System.Xml.XmlDocument doc, IDTSInfoEvents infoEvents)
        {
            //create node in the package xml document
            XmlElement taskElement = doc.CreateElement(string.Empty, "myTask", string.Empty);

            // create attributes in the node that represent the custom properties and add each to the element

            // Boolean indicating if you are using a connection manager or variable
            XmlAttribute myTaskXmlAttribute = doc.CreateAttribute(string.Empty, "HasConnectionmanagerSource", string.Empty);
            myTaskXmlAttribute.Value = this._hasConnectionmanagerSource.ToString();
            taskElement.Attributes.Append(myTaskXmlAttribute);

            // The GUID from the connection manager
            myTaskXmlAttribute = doc.CreateAttribute(string.Empty, "SelectedConnectionManagerIDSource", string.Empty);
            myTaskXmlAttribute.Value = this._selectedConnectionManagerIDSource.ToString();
            taskElement.Attributes.Append(myTaskXmlAttribute);

            // The GUID from the variable
            myTaskXmlAttribute = doc.CreateAttribute(string.Empty, "SelectedVariableIDSource", string.Empty);
            myTaskXmlAttribute.Value = this._selectedVariableIDSource.ToString();
            taskElement.Attributes.Append(myTaskXmlAttribute);

            //add the new element to the package document
            doc.AppendChild(taskElement);
        }
        #endregion

        #region CUSTOM Methods for getting path via Variable or Connectionmanager
        private string GetFilePathSource(ConnectionManager selectedConnectionManager)
        {
            if (selectedConnectionManager != null)
            {
                if (selectedConnectionManager.CreationName == "EXCEL")
                {
                    return selectedConnectionManager.Properties["ExcelFilePath"].GetValue(_selectedConnectionManagerSource).ToString();
                }
                else
                {
                    return selectedConnectionManager.ConnectionString;
                }
            }
            else
            {
                return "";
            }
        }

        private string GetFilePathSource(Variable selectedVariable)
        {
            if (selectedVariable != null)
            {
                return (String)_selectedVariableSource.Value;
            }
            else
            {
                return "";
            }
        }

        private Variable FindVariable(VariableDispenser variableDispenser, string variableID)
        {
            Variable tempVariable = null;
            if (variableDispenser.Contains(_selectedVariableIDSource))
            {
                Variables vars = null;
                variableDispenser.LockOneForRead(variableID, ref vars);

                if (vars != null)
                {
                    foreach (Variable var in vars)
                    {
                        if (var.ID == variableID)
                        {
                            tempVariable = var;
                        }
                    }
                }
                vars.Unlock();
            }
            return tempVariable;
        }

        private ConnectionManager FindConnectionManager(Connections connections, string connectionManagerID)
        {
            ConnectionManager tempConnManager = null;
            foreach (ConnectionManager connManager in connections)
            {
                if (connManager.ID == connectionManagerID)
                {
                    tempConnManager = connManager;
                    return tempConnManager;
                }
            }
            return tempConnManager;
        }
        #endregion
    }
}
