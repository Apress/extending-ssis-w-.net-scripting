﻿namespace ScriptingBook.myTask
{
    partial class myTaskEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(myTaskEditor));
            this.gbSource = new System.Windows.Forms.GroupBox();
            this.radConnectionSource = new System.Windows.Forms.RadioButton();
            this.cmbConnectionsSource = new System.Windows.Forms.ComboBox();
            this.lblPathSource = new System.Windows.Forms.Label();
            this.lblVariablesSource = new System.Windows.Forms.Label();
            this.lblConnectionsSource = new System.Windows.Forms.Label();
            this.cmbVariablesSource = new System.Windows.Forms.ComboBox();
            this.txtFilePathFinalSource = new System.Windows.Forms.TextBox();
            this.radVariableSource = new System.Windows.Forms.RadioButton();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.gbSource.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSource
            // 
            this.gbSource.Controls.Add(this.radConnectionSource);
            this.gbSource.Controls.Add(this.cmbConnectionsSource);
            this.gbSource.Controls.Add(this.lblPathSource);
            this.gbSource.Controls.Add(this.lblVariablesSource);
            this.gbSource.Controls.Add(this.lblConnectionsSource);
            this.gbSource.Controls.Add(this.cmbVariablesSource);
            this.gbSource.Controls.Add(this.txtFilePathFinalSource);
            this.gbSource.Controls.Add(this.radVariableSource);
            this.gbSource.Location = new System.Drawing.Point(12, 12);
            this.gbSource.Name = "gbSource";
            this.gbSource.Size = new System.Drawing.Size(555, 166);
            this.gbSource.TabIndex = 28;
            this.gbSource.TabStop = false;
            this.gbSource.Text = "Source";
            // 
            // radConnectionSource
            // 
            this.radConnectionSource.AutoSize = true;
            this.radConnectionSource.Checked = true;
            this.radConnectionSource.Location = new System.Drawing.Point(6, 19);
            this.radConnectionSource.Name = "radConnectionSource";
            this.radConnectionSource.Size = new System.Drawing.Size(141, 17);
            this.radConnectionSource.TabIndex = 19;
            this.radConnectionSource.TabStop = true;
            this.radConnectionSource.Text = "Use connectionmanager";
            this.radConnectionSource.UseVisualStyleBackColor = true;
            this.radConnectionSource.CheckedChanged += new System.EventHandler(this.radConnectionSource_CheckedChanged);
            // 
            // cmbConnectionsSource
            // 
            this.cmbConnectionsSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbConnectionsSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbConnectionsSource.FormattingEnabled = true;
            this.cmbConnectionsSource.Location = new System.Drawing.Point(152, 40);
            this.cmbConnectionsSource.Name = "cmbConnectionsSource";
            this.cmbConnectionsSource.Size = new System.Drawing.Size(387, 21);
            this.cmbConnectionsSource.TabIndex = 2;
            this.cmbConnectionsSource.SelectedIndexChanged += new System.EventHandler(this.cmbConnectionsSource_SelectedIndexChanged);
            // 
            // lblPathSource
            // 
            this.lblPathSource.Location = new System.Drawing.Point(18, 131);
            this.lblPathSource.Name = "lblPathSource";
            this.lblPathSource.Size = new System.Drawing.Size(77, 21);
            this.lblPathSource.TabIndex = 14;
            this.lblPathSource.Text = "Path:";
            this.lblPathSource.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVariablesSource
            // 
            this.lblVariablesSource.Location = new System.Drawing.Point(18, 94);
            this.lblVariablesSource.Name = "lblVariablesSource";
            this.lblVariablesSource.Size = new System.Drawing.Size(77, 21);
            this.lblVariablesSource.TabIndex = 22;
            this.lblVariablesSource.Text = "Variable:";
            this.lblVariablesSource.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblConnectionsSource
            // 
            this.lblConnectionsSource.Location = new System.Drawing.Point(18, 39);
            this.lblConnectionsSource.Name = "lblConnectionsSource";
            this.lblConnectionsSource.Size = new System.Drawing.Size(77, 21);
            this.lblConnectionsSource.TabIndex = 3;
            this.lblConnectionsSource.Text = "Connection:";
            this.lblConnectionsSource.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbVariablesSource
            // 
            this.cmbVariablesSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbVariablesSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVariablesSource.FormattingEnabled = true;
            this.cmbVariablesSource.Location = new System.Drawing.Point(152, 95);
            this.cmbVariablesSource.Name = "cmbVariablesSource";
            this.cmbVariablesSource.Size = new System.Drawing.Size(387, 21);
            this.cmbVariablesSource.TabIndex = 21;
            this.cmbVariablesSource.SelectedIndexChanged += new System.EventHandler(this.cmbVariablesSource_SelectedIndexChanged);
            // 
            // txtFilePathFinalSource
            // 
            this.txtFilePathFinalSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFilePathFinalSource.CausesValidation = false;
            this.txtFilePathFinalSource.Location = new System.Drawing.Point(152, 132);
            this.txtFilePathFinalSource.Name = "txtFilePathFinalSource";
            this.txtFilePathFinalSource.ReadOnly = true;
            this.txtFilePathFinalSource.Size = new System.Drawing.Size(387, 20);
            this.txtFilePathFinalSource.TabIndex = 15;
            // 
            // radVariableSource
            // 
            this.radVariableSource.AutoSize = true;
            this.radVariableSource.Location = new System.Drawing.Point(6, 68);
            this.radVariableSource.Name = "radVariableSource";
            this.radVariableSource.Size = new System.Drawing.Size(84, 17);
            this.radVariableSource.TabIndex = 20;
            this.radVariableSource.Text = "Use variable";
            this.radVariableSource.UseVisualStyleBackColor = true;
            this.radVariableSource.CheckedChanged += new System.EventHandler(this.radVariableSource_CheckedChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(492, 188);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 30;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(411, 188);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 29;
            this.btnSave.Text = "&OK";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // myTaskEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 242);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbSource);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "myTaskEditor";
            this.Text = "myTaskEditor";
            this.Load += new System.EventHandler(this.myTaskEditor_Load);
            this.gbSource.ResumeLayout(false);
            this.gbSource.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSource;
        private System.Windows.Forms.RadioButton radConnectionSource;
        private System.Windows.Forms.ComboBox cmbConnectionsSource;
        private System.Windows.Forms.Label lblPathSource;
        private System.Windows.Forms.Label lblVariablesSource;
        private System.Windows.Forms.Label lblConnectionsSource;
        private System.Windows.Forms.ComboBox cmbVariablesSource;
        private System.Windows.Forms.TextBox txtFilePathFinalSource;
        private System.Windows.Forms.RadioButton radVariableSource;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;

    }
}