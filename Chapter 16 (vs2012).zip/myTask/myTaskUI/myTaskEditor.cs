﻿using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Design;

namespace ScriptingBook.myTask
{
    public partial class myTaskEditor : Form
    {
        #region General Task Methods
        // Setting and getting taskhost
        private TaskHost _taskHost;
        public TaskHost TaskHost
        {
            get { return _taskHost; }
            set { _taskHost = value; }
        }

        // Getting connections, setting is done with ServiceProvider
        private Connections _connections;
        public Connections connections
        {
            get { return _connections; }
        }

        // Gets or sets the serviceprovider. Used for getting
        // f.a. the VariablesProvider and ConnectionsProvider
        private IServiceProvider _serviceProvider = null;
        public IServiceProvider ServiceProvider
        {
            get
            {
                return _serviceProvider;
            }
            set
            {
                _serviceProvider = value;
                // Get connections from the services provider
                // The code looks difficult, but it is just a cast
                _connections = ((IDtsConnectionService)
                                (value.GetService(typeof(IDtsConnectionService))))
                                .GetConnections();
            }
        }

        // Default constructor
        public myTaskEditor()
        {
            InitializeComponent();
        }

        // Constructor to set taskhost and serviceprovider
        // See GetView in myTaskInterface.cs
        public myTaskEditor(TaskHost taskHost, IServiceProvider serviceprovider)
        {
            InitializeComponent();

            this.TaskHost = taskHost;
            this.ServiceProvider = serviceprovider;
        }
        #endregion

        #region Page Load
        private void myTaskEditor_Load(object sender, EventArgs e)
        {
            // Fill the ComboBox with variables from the package,
            // but only show string variables and non-system variables
            if (this._taskHost != null && this._taskHost.Variables != null)
            {

                cmbVariablesSource.Items.Clear();
                cmbVariablesSource.DisplayMember = "Name";
                cmbVariablesSource.ValueMember = "QualifiedName";
                cmbVariablesSource.Items.Add("<Choose variable>");
                cmbVariablesSource.Items.Add("<New variable>");  // open new variabele popup
                foreach (Variable variable in _taskHost.Variables)
                {
                    if ((!variable.SystemVariable) && (variable.DataType == TypeCode.String))
                    {
                        this.cmbVariablesSource.Items.Add(variable);
                    }
                }
            }

            // Fill the ComboBox with connection managers from the package,
            // but only select FILE, FLATFILE and EXCEL connection managers.
            if (this._taskHost != null && this._connections != null)
            {
                cmbConnectionsSource.Items.Clear();
                cmbConnectionsSource.DisplayMember = "Name";
                cmbConnectionsSource.ValueMember = "ID";
                cmbConnectionsSource.Items.Add("<Choose connectionmanager>");
                // This options will open new connection manager popup
                cmbConnectionsSource.Items.Add("<New connectionmanager>"); 
                foreach (ConnectionManager connection in this._connections)
                {
                    string ConnectionType = connection.CreationName;

                    if (ConnectionType == "FILE" ||
                        ConnectionType == "EXCEL" ||
                        ConnectionType == "FLATFILE")
                    {
                        cmbConnectionsSource.Items.Add(connection);
                    }
                }
            }


            // Get the properties from the Task and fill the form.
            if (this._taskHost != null)
            {
                // Only fill form if a value is found in the properties
                if (this._taskHost.Properties["HasConnectionmanagerSource"] != null)
                {
                    // A connection manager is selected
                    if ((bool)this._taskHost.Properties["HasConnectionmanagerSource"].GetValue(_taskHost))
                    {
                        this.radConnectionSource.Checked = true;
                        this.cmbConnectionsSource.Enabled = true;
                        this.cmbVariablesSource.Enabled = false;
                        this.cmbVariablesSource.SelectedIndex = 0;
                        // Set the ConnectionManagerID
                        if (this._taskHost.Properties["SelectedConnectionManagerIDSource"] != null)
                        {
                            object obj = this._taskHost.Properties["SelectedConnectionManagerIDSource"].GetValue(_taskHost);
                            if (obj == null)
                            {
                                // No connection manager in property
                                this.cmbConnectionsSource.SelectedIndex = 0;
                            }
                            else
                            {
                                ConnectionManager cm = null;
                                cm = FindConnectionManager(obj.ToString().Trim());
                                if (cm != null)
                                {
                                    // Connection manager found, now select it in combobox
                                    this.cmbConnectionsSource.SelectedItem = cm;
                                }
                                else
                                {
                                    // Connection manager not found
                                    this.cmbConnectionsSource.SelectedIndex = 0;
                                }
                            }
                        }
                    }
                    // A variable is selected
                    else
                    {
                        this.radVariableSource.Checked = true;
                        this.cmbVariablesSource.Enabled = true;
                        this.cmbConnectionsSource.Enabled = false;
                        this.cmbConnectionsSource.SelectedIndex = 0;
                        // Set the VariableID
                        if (this._taskHost.Properties["SelectedVariableIDSource"] != null)
                        {
                            object obj = this._taskHost.Properties["SelectedVariableIDSource"].GetValue(_taskHost);
                            if (obj == null)
                            {
                                // No variable in property
                                this.cmbVariablesSource.SelectedIndex = 0;
                                return;
                            }
                            Variable var = FindVariable(this._taskHost.Properties["SelectedVariableIDSource"].GetValue(_taskHost).ToString().Trim());
                            if (var != null)
                            {
                                // Variable found, now select it in combobox
                                this.cmbVariablesSource.SelectedItem = var;
                            }
                            else
                            {
                                // Variable not found
                                this.cmbVariablesSource.SelectedIndex = 0;
                            }
                        }
                    }
                }
            }
            // Initial values (for new tasks)
            else
            {
                this.radConnectionSource.Checked = true;
                this.cmbConnectionsSource.Enabled = true;
                this.cmbConnectionsSource.SelectedIndex = 0;
                this.cmbVariablesSource.Enabled = false;
                this.cmbVariablesSource.SelectedIndex = 0;
            }
        }
        #endregion

        #region Button Methods OK end Cancel
        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Cancel editor / close window
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Safe Source values (radiobutton, connectionmanager, variable) in tasks properties.
            // Selected Connection Manager or Variable is available via variables that where
            // filled by onchange events from the comboboxes.
            this._taskHost.Properties["HasConnectionmanagerSource"].SetValue(this._taskHost, radConnectionSource.Checked);
            if (radConnectionSource.Checked)
            {
                this._taskHost.Properties["SelectedVariableIDSource"].SetValue(this._taskHost, string.Empty);

                if (this.cmbConnectionsSource.SelectedIndex != 0)
                {
                    this._taskHost.Properties["SelectedConnectionManagerIDSource"].SetValue(this._taskHost, selectedConnectionManagerSource.ID);
                }
                else
                {
                    this._taskHost.Properties["SelectedConnectionManagerIDSource"].SetValue(this._taskHost, string.Empty);
                }
            }
            else
            {
                this._taskHost.Properties["SelectedConnectionManagerIDSource"].SetValue(this._taskHost, string.Empty);

                if (this.cmbVariablesSource.SelectedIndex != 0)
                {
                    this._taskHost.Properties["SelectedVariableIDSource"].SetValue(this._taskHost, selectedVariableSource.ID);
                }
                else
                {
                    this._taskHost.Properties["SelectedVariableIDSource"].SetValue(this._taskHost, string.Empty);
                }
            }

            // Close editor
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        #endregion

        #region Onchange events methods Comboboxes
// Variable to store the selected connectionmanager. It will be filled by
// the SelectedIndexChange event and used by the OK button click event.
private ConnectionManager selectedConnectionManagerSource = null;

// Method to set the selected connectionmanager
private void cmbConnectionsSource_SelectedIndexChanged(object sender, EventArgs e)
{
    ComboBox combobox = (ComboBox)sender;

    // If <Choose connectionmanager> is selected then empty the textbox with the path
    if (combobox.SelectedIndex == 0)
    {
        this.txtFilePathFinalSource.Text = "";
        return;
    }

    // If <New connectionmanager> is selected then popup to create a new connection manager
    if (combobox.SelectedIndex == 1)
    {
        int currentIndex = -1;
        IDtsConnectionService _dtsConnectionService = _serviceProvider.GetService(typeof(IDtsConnectionService)) as IDtsConnectionService;
        ArrayList createdConnection = _dtsConnectionService.CreateConnection(Prompt.ShowConnectionManagerTypeDialog());
        if (createdConnection.Count > 0)
        {
            ConnectionManager newConnectionManager = (ConnectionManager)createdConnection[0];
            _dtsConnectionService.AddConnectionToPackage(newConnectionManager);
            currentIndex = combobox.Items.Add(newConnectionManager);
            combobox.SelectedIndex = currentIndex;
            return;
        }
        else
        {
            // Cancel was clicked in popup
            combobox.SelectedIndex = 0;
            return;
        }
    }

    // Fill the private variable to store the selected connectionmanager
    selectedConnectionManagerSource = (ConnectionManager)combobox.SelectedItem;

    // If the variable is still null then clear form
    if (selectedConnectionManagerSource == null)
    {
        this.cmbConnectionsSource.SelectedIndex = 0;
        this.txtFilePathFinalSource.Text = "";
        return;
    }

    // Get the path of the connectionmanager. For Excel connectionmanagers
    // you should use ExcelFilePath property instead of the connectionstring
    if (selectedConnectionManagerSource.CreationName == "EXCEL")
    {
        this.txtFilePathFinalSource.Text = selectedConnectionManagerSource.Properties["ExcelFilePath"].GetValue(selectedConnectionManagerSource).ToString();
    }
    else
    {
        this.txtFilePathFinalSource.Text = selectedConnectionManagerSource.ConnectionString;
    }
}

// Variable to store the selected variable. It will be filled by
// the SelectedIndexChange event and used by the OK button click event.
private Variable selectedVariableSource = null;

        // Method to set the selected variable
        private void cmbVariablesSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox combobox = (ComboBox)sender;

            // If <Choose variable> is selected then empty the textbox with the path
            if (combobox.SelectedIndex == 0)
            {
                this.txtFilePathFinalSource.Text = "";
                return;
            }

            // If <New variable> is selected then popup to create a new variable
            if (combobox.SelectedIndex == 1)
            {
                int currentdIndex = -1;
                IDtsVariableService _dtsVariableService = _serviceProvider.GetService(typeof(IDtsVariableService)) as IDtsVariableService;
                Variable newVariable = _dtsVariableService.PromptAndCreateVariable(this, null, "FilePath", "User", typeof(String));
                if (newVariable != null)
                {
                    currentdIndex = combobox.Items.Add(newVariable);
                    combobox.SelectedIndex = currentdIndex;
                    return;
                }
                else
                {
                    // Cancel was clicked in popup
                    combobox.SelectedIndex = 0;
                    return;
                }
            }

            // Fill the private variable to store the selected variable
            selectedVariableSource = (Variable)combobox.SelectedItem;

            // If the variable is still null then clear form
            if (selectedVariableSource == null)
            {
                this.cmbVariablesSource.SelectedIndex = 0;
                this.txtFilePathFinalSource.Text = "";
                return;
            }

            // Show path in textbox
            this.txtFilePathFinalSource.Text = (String)selectedVariableSource.Value;
        }
        #endregion

        #region Radio buttons
        private void radConnectionSource_CheckedChanged(object sender, EventArgs e)
        {
            // Enable/disable other fields when
            // the radio button changes
            RadioButton rad = (RadioButton)sender;

            if (!rad.Checked)
            {
                this.cmbConnectionsSource.Enabled = false;
                this.cmbVariablesSource.Enabled = true;
                if (this.cmbVariablesSource.SelectedIndex != 0)
                {
                    Variable var = ((Variable)this.cmbVariablesSource.SelectedItem);
                    if (var != null)
                    {
                        this.txtFilePathFinalSource.Text = ((Variable)this.cmbVariablesSource.SelectedItem).Value.ToString();
                    }
                }
            }
        }

        private void radVariableSource_CheckedChanged(object sender, EventArgs e)
        {
            // Enable/disable other fields when
            // the radio button changes
            RadioButton rad = (RadioButton)sender;
            if (!rad.Checked)
            {
                this.cmbConnectionsSource.Enabled = true;
                this.cmbVariablesSource.Enabled = false;
                if (this.cmbConnectionsSource.SelectedIndex != 0)
                {
                    ConnectionManager temp = ((ConnectionManager)this.cmbConnectionsSource.SelectedItem);
                    if (temp != null)
                    {
                        if (temp.CreationName == "EXCEL")
                        {
                            this.txtFilePathFinalSource.Text = temp.Properties["ExcelFilePath"].GetValue(temp).ToString();
                        }
                        else
                        {
                            this.txtFilePathFinalSource.Text = temp.ConnectionString;
                        }
                    }
                }
            }
        }
        #endregion

        #region Methods to find Connectionmanager and Variable by id
        private ConnectionManager FindConnectionManager(string connectionManagerID)
        {
            // This methods loops through all connection managers
            // and returns the one that matches the GUID.
            foreach (ConnectionManager connManager in this._connections)
            {
                if (connManager.ID == connectionManagerID)
                {
                    return connManager;
                }
            }
            return null;
        }

        private Variable FindVariable(string variableID)
        {
            // This methods loops through all variables
            // and returns the one that matches the GUID.
            foreach (Variable var in this._taskHost.Variables)
            {
                if (var.ID == variableID)
                {
                    return var;
                }
            }
            return null;
        }
        #endregion
    }

    #region ShowConnectionManagerTypeDialog
    // A dialog for creating a new Connection Manager.
    // You can choose between File, FLATFILE or EXCEL
    // and then the corresponding dialog will open.

    // This could also be done in a seperate windows
    // form which is easier to format.
    public static class Prompt
    {
        public static string ShowConnectionManagerTypeDialog()
        {
            Form prompt = new Form();
            prompt.Width = 400;
            prompt.Height = 200;
            prompt.Text = "Choose Connection Manager type";
            prompt.MaximizeBox = false;
            prompt.MinimizeBox = false;
            prompt.ControlBox = false;


            RadioButton radConnectionManagerFile = new RadioButton() { Left = 50, Top = 20, Width = 300, Text = "Connection manager for files", Checked = true };
            RadioButton radConnectionManagerFlatFile = new RadioButton() { Left = 50, Top = 50, Width = 300, Text = "Connection manager for flat files" };
            RadioButton radConnectionManagerExcel = new RadioButton() { Left = 50, Top = 80, Width = 300, Text = "Connection manager for Excel files" };

            Button confirmation = new Button() { Text = "Ok", Left = 150, Width = 100, Top = 110 };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(radConnectionManagerFile);
            prompt.Controls.Add(radConnectionManagerFlatFile);
            prompt.Controls.Add(radConnectionManagerExcel);
            prompt.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width / 2 - prompt.Width / 2, Screen.PrimaryScreen.WorkingArea.Height / 2 - prompt.Height / 2);
            prompt.ShowDialog();

            string res = "";
            if (radConnectionManagerExcel.Checked)
            {
                res = "EXCEL";
            }
            else if (radConnectionManagerFlatFile.Checked)
            {
                res = "FLATFILE";
            }
            else
            {
                res = "FILE";
            }

            return res;
        }
    }
    #endregion
}
