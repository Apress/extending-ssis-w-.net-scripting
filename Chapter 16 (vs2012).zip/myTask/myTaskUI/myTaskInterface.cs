﻿using System;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Design;

// Class, Interfacing for task editor
namespace ScriptingBook.myTask
{
    public class myTaskInterface : IDtsTaskUI
    {
        private TaskHost _taskHost;
        private IServiceProvider _serviceProvider;

        public myTaskInterface()
        {
        }

        // Get taskhost and service provider
        // and fill class variables
        public void Initialize(TaskHost taskHost, IServiceProvider serviceProvider)
        {
            _taskHost = taskHost;
            _serviceProvider = serviceProvider;
        }

        public ContainerControl GetView()
        {
            myTaskEditor editor = new myTaskEditor();
            editor.TaskHost = this._taskHost;
            editor.ServiceProvider = this._serviceProvider;
            return editor;
        }

        public void Delete(IWin32Window parentWindow)
        {
        }

        public void New(IWin32Window parentWindow)
        {
        }
    }
}
