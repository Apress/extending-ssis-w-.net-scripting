#################################################################################################
# Change path of assembly file
#################################################################################################

$AssemblyPath = "D:\myMethodsForSSIS.dll"

#################################################################################################
# DO NOT EDIT BELOW THIS LINE
#################################################################################################

# Check if assembly file exists
if (-Not (Test-Path $AssemblyPath))
{
    # Assembly not found, stop deployment
    Return "Assembly file" $AssemblyPath "doesn't exists"
}
else
{
	# Assembly found, continue
	Write-Host "Assembly file" $AssemblyPath "found"
}

# Load .NET assembly System.EnterpriseServices.Internal.Publish
if ( $null -eq ([AppDomain]::CurrentDomain.GetAssemblies() |? { $_.FullName -eq "System.EnterpriseServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" }) ) {
    [System.Reflection.Assembly]::Load("System.EnterpriseServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a") | Out-Null
}
$PublishObject = New-Object System.EnterpriseServices.Internal.Publish

# Try to load the assembly to see if it's strong named
$LoadedAssembly = [System.Reflection.Assembly]::LoadFile($AssemblyPath)
if ($LoadedAssembly.GetName().GetPublicKey().Length -eq 0) 
{
    Return "Assembly file" $AssemblyPath "must be strongly signed...."
}

# Deploy to Global Assembly Cache
Write-Verbose "Installing $AssemblyPath in GAC"
$PublishObject.GacInstall($AssemblyPath)

