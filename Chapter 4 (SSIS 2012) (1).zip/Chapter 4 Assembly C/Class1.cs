﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;   // Added

namespace myMethodsForSSIS
{
  // A static class with email methods
  public static class EmailMethods
  {
    // A boolean method that validates an email address     
    // with a regex pattern.     
    public static bool IsCorrectEmail(String emailAddress)
    {
      // The pattern for email         
      string emailAddressPattern = @"^(([^<>()[\]\\.,;:\s@\""]+"
          + @"(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@"
          + @"((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
          + @"\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+"
          + @"[a-zA-Z]{2,}))$";
      // Create a regex object with the pattern
      Regex emailAddressRegex = new Regex(emailAddressPattern);
      // Check if it is match and return that value (boolean)
      return emailAddressRegex.IsMatch(emailAddress);
    }
  }
}
