﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Text.RegularExpressions  ' Added
Namespace myMethodsForSSIS
  ' A module with email methods
  Public Module EmailMethods
    ' A boolean method that validates an email address     
    ' with a regex pattern.     
    Public Function IsCorrectEmail(emailAddress As [String]) As Boolean
      ' The pattern for email         
      Dim emailAddressPattern As String = "^(([^<>()[\]\\.,;:\s@\""]+" &
          "(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@" &
          "((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}" &
          "\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+" &
          "[a-zA-Z]{2,}))$"
      ' Create a regex object with the pattern
      Dim emailAddressRegex As New Regex(emailAddressPattern)
      ' Check if it is match and return that value (boolean)
      Return emailAddressRegex.IsMatch(emailAddress)
    End Function
  End Module
End Namespace